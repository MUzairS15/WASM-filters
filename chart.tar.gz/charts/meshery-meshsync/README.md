# meshery-meshsync

![Version: 0.5.0](https://img.shields.io/badge/Version-0.5.0-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: stable-latest](https://img.shields.io/badge/AppVersion-stable--latest-informational?style=flat-square)

Meshery MeshSync

## Maintainers

| Name | Email | Url |
| ---- | ------ | --- |
| Layer5 Authors | <community@layer5.io> |  |
| darrenlau | <panyuenlau@gmail.com> |  |
| leecalcote | <lee.calcote@layer5.io> |  |

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| broker.name | string | `"meshery-broker"` |  |
| broker.namespace | string | `"meshery"` |  |
| name | string | `"meshery-meshsync"` |  |
| replica | int | `1` |  |

